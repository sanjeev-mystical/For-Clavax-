from django import forms
from django.db import models
from datetime import datetime, date


class Class(models.Model):
    class_name = models.CharField(max_length=20)
    create_date = models.DateTimeField(auto_now_add=False)

    class Meta:
        db_table = 'Class'

    def __str__(self):
        return self.class_name


class Student(models.Model):
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    email_id = models.CharField(max_length=30)
    password = models.CharField(verbose_name="Password", max_length=500, null=True, blank=True)
    date = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    image = models.ImageField(upload_to='images/')
    Class = models.ForeignKey('school.class', on_delete=models.SET_NULL, null=True, blank=True)

    class Meta:
        db_table = 'Student'

    def __str__(self):
        return self.first_name
