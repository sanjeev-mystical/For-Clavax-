from django.contrib import admin
from school.models import*

admin.site.register(Class)
admin.site.register(Student)

